package center.claims.mirascon.mirascon.Interface;

public interface OnDialogButtonClickListener {
    void onPositiveButtonClicked();

    void onNegativeButtonClicked();
}
