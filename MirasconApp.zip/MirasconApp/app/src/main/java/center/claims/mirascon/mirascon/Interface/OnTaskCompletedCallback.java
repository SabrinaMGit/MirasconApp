package center.claims.mirascon.mirascon.Interface;

public interface OnTaskCompletedCallback {

    void onTaskCompleted();

}
